---
name: XuperChain Feature Request Template
about: Let us know if you have a cool idea.
title: ''
labels: ''
assignees: ''

---

**Brief of your idea**
Describe here

**What could be better if XuperChain using your idea**
Describe the benefits of your idea

**Are there any side effects?**
Describe what might be worse.

**Additional information**
If possible, include a minimal, complete, and verifiable example to help us identify the issue. 
