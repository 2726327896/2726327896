package common

const (
	SubModName = "xchain"
)
